import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import { XmplProvider } from 'xmpl-react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Content } from './components/Content';
import { ErrorPage } from './components/ErrorPage';
import { NewRecipientForm } from './components/NewRecipientForm';
import { ReferredRecipientData } from './components/ReferredRecipientData';

const root = ReactDOM.createRoot(document.getElementById('root'));
var xmpcfg = {
    access: {
        accessToken: '841fba0a-ef98-4f9c-87b2-cfb7bb2026b6_c96a2e52-cd3a-4633-9cc8-5d7e1c32a428_60d7fac0d0d74b698441a02137140065',
        url: 'https://marketingx.xmpie.net/XMPieXMPL_REST_API',
        circleProjectID:'c96a2e52-cd3a-4633-9cc8-5d7e1c32a428',
        circleProjectName: 'XMPL Sample 5.0'
    }
};
root.render(
    <React.StrictMode>
        <XmplProvider xmpcfg={xmpcfg}>
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<App/>}/>
                    <Route path='/content' element={<Content/>}/>
                    <Route path='/errorPage' element={<ErrorPage/>}/>
                    <Route path='/anonymous' element={<NewRecipientForm type='anon'/>}/>
                    <Route path='/ref' element={<NewRecipientForm type='ref'/>}/>
                    <Route path='/referredRecipientData' element={<ReferredRecipientData/>}/>
                </Routes>
            </BrowserRouter>
        </XmplProvider>
    </React.StrictMode>
);
