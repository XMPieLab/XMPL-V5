import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import { XmplProvider } from 'xmpl-react';

const root = ReactDOM.createRoot(document.getElementById('root'));
const xmpcfg = {
    access: {
        accessToken: 'bdbd5a21-d496-4e2c-bb22-11448af05f87_bbe47f06-1c85-4f2c-a49f-11f37fd69b71_603ec87f7e2d41d59837769974b25b5a',
        url: 'http://xmpl02.xmpie.net/XMPieXMPL_REST_API',
        circleProjectID: 'bbe47f06-1c85-4f2c-a49f-11f37fd69b71',
        circleProjectName: 'sample'
    }
};
root.render(
    <React.StrictMode>
        <XmplProvider xmpcfg={xmpcfg}>
            <App/>
        </XmplProvider>
    </React.StrictMode>
);
