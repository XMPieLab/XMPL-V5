start - folder you need to start guide with
completed - folder you will have in the end of the guide
full_example - folder similar to completed but also includes such things like : 
	routing, tracking, error handling, adding new recipients and referred friend