import './assets/css/main.css';
import { Header } from './components/Header';
import { Banner } from './components/Banner';
import { Footer } from './components/Footer';
import { MainBlock } from './components/MainBlock';
import { Contact } from './components/Contact';

function App() {
    return (
            <div className="App">
                <div id="wrapper">
                    <Header/>
                    <Banner/>
                    <MainBlock/>
                    <Contact/>
                    <Footer/>
                </div>
            </div>
    );
}
export default App;
