export  const MainBlock = () => {
    return (
        <div id="main">
            <section id="one" className="tiles">
                <article>
					<span className="image">
                        <img src="images/pic01.jpg" alt=""/>
					</span>
                    <header className="major">
                        <h3><a href="content.html" className="link">Excitement</a></h3>
                        <p>Get out and about!</p>
                    </header>
                </article>
                <article>
									<span className="image">
										<img src="images/pic02.jpg" alt=""/>
									</span>
                    <header className="major">
                        <h3><a href="content.html" className="link">Breathe</a></h3>
                        <p>Take a break!</p>
                    </header>
                </article>
                <article>
									<span className="image">
										<img src="images/pic03.jpg" alt=""/>
									</span>
                    <header className="major">
                        <h3><a href="content.html" className="link">Enjoy</a></h3>
                        <p>Indulge in the best</p>
                    </header>
                </article>
                <article>
									<span className="image">
										<img src="images/pic04.jpg" alt=""/>
									</span>
                    <header className="major">
                        <h3><a href="content.html" className="link">Relax</a></h3>
                        <p>Discover something new</p>
                    </header>
                </article>
            </section>
            <section id="two">
                <div className="inner">
                    <header className="major">
                        <h2>About Round Travel</h2>
                    </header>
                    <p>At Round Travel we personalize the travel experience by offering the best destinations,
                        tours
                        and itineraries based on your preferences!</p>
                    <ul className="actions">
                        <li><a href="" className="button next">Get Started</a></li>
                    </ul>
                </div>
            </section>
        </div>
    )
}
